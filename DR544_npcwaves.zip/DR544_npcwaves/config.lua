Config = {}

--------------------------------------------------
-- ALLGEMEIN
--------------------------------------------------

Config.Debug = false

Config.TimeBetweenWaves = 4

Config.DeletePedsOnStop = true


--------------------------------------------------
-- ZONEN
--------------------------------------------------

Config.Zones = {

    --------------------------------------------------
    -- HUMANE LABS
    --------------------------------------------------

    ['humane_labs'] = {

        label = 'HUMANE LABS',

        coords = vector3(
            3619.47,
            3736.33,
            28.69
        ),

        radius = 100.0,

        cooldown = 30,

        waves = 8,

        npcsPerWave = {
            20,
            30,
            40,
            50,
            60,
            70,
            80,
            100
        },

        models = {
            's_m_m_security_01',
            's_m_m_armoured_01',
            's_m_m_armoured_02'
        },

        weapons = {
            'WEAPON_SMG',
            'WEAPON_CARBINERIFLE_MK2'
        },

        npcHealth = 2000,

        npcArmor = 1000,

        npcAccuracy = 55,

        spawnDistance = 35.0,

        blip = false,

        blipSprite = 499,

        blipColor = 1

    },


    --------------------------------------------------
    -- ÖL-RIG
    --------------------------------------------------

    ['oil_rig'] = {

        label = 'ÖL-RIG',

        coords = vector3(
            2985.12,
            -711.25,
            25.75
        ),

        radius = 120.0,

        cooldown = 45,

        waves = 8,

        npcsPerWave = {
            5,
            5,
            6,
            6,
            7,
            8,
            9,
            12
        },

        models = {
            's_m_m_armoured_01',
            's_m_y_blackops_01',
            's_m_y_blackops_02'
        },

        weapons = {
            'WEAPON_SMG',
            'WEAPON_CARBINERIFLE',
            'WEAPON_ASSAULTRIFLE'
        },

        npcHealth = 250,

        npcArmor = 150,

        npcAccuracy = 65,

        spawnDistance = 40.0,

        blip = true,

        blipSprite = 410,

        blipColor = 5

    }

}