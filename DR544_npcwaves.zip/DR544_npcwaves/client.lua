local activeZone = nil
local activeWave = 0
local activePeds = {}

local waveRunning = false

local zoneCooldowns = {}

local WAVE_PED_GROUP = nil


--------------------------------------------------
-- RELATIONSHIP GROUP
--------------------------------------------------

CreateThread(function()

    AddRelationshipGroup(
        'WCC_WAVE_ATTACKERS'
    )

    WAVE_PED_GROUP =
        GetHashKey(
            'WCC_WAVE_ATTACKERS'
        )

    --------------------------------------------------
    -- NPC <-> NPC
    -- 0 = freundlich
    --------------------------------------------------

    SetRelationshipBetweenGroups(
        0,
        WAVE_PED_GROUP,
        WAVE_PED_GROUP
    )

    --------------------------------------------------
    -- NPC -> PLAYER
    -- 5 = hassen
    --------------------------------------------------

    SetRelationshipBetweenGroups(
        5,
        WAVE_PED_GROUP,
        GetHashKey('PLAYER')
    )

    --------------------------------------------------
    -- PLAYER -> NPC
    --------------------------------------------------

    SetRelationshipBetweenGroups(
        5,
        GetHashKey('PLAYER'),
        WAVE_PED_GROUP
    )

end)


--------------------------------------------------
-- NOTIFICATION
--------------------------------------------------

local function Notify(message)

    BeginTextCommandThefeedPost(
        'STRING'
    )

    AddTextComponentSubstringPlayerName(
        message
    )

    EndTextCommandThefeedPostTicker(
        false,
        false
    )

end


--------------------------------------------------
-- MODEL LADEN
--------------------------------------------------

local function LoadModel(model)

    local hash = joaat(model)

    if not IsModelInCdimage(hash) then

        print(
            '[wcc_waveattack] Ungültiges Model: ' ..
            tostring(model)
        )

        return nil

    end

    RequestModel(hash)

    local timeout = 0

    while not HasModelLoaded(hash) do

        Wait(50)

        timeout = timeout + 1

        if timeout >= 200 then

            print(
                '[wcc_waveattack] Model konnte nicht geladen werden: ' ..
                tostring(model)
            )

            return nil

        end

    end

    return hash

end


--------------------------------------------------
-- SPAWN POSITION
--------------------------------------------------

local function GetSpawnPosition(zone)

    local player =
        PlayerPedId()

    local playerCoords =
        GetEntityCoords(player)

    for attempt = 1, 30 do

        local angle =
            math.random() *
            math.pi *
            2

        local distance =
            zone.spawnDistance +
            math.random() * 15.0

        local x =
            playerCoords.x +
            math.cos(angle) *
            distance

        local y =
            playerCoords.y +
            math.sin(angle) *
            distance

        local z =
            playerCoords.z + 50.0

        local found, groundZ =
            GetGroundZFor_3dCoord(
                x,
                y,
                z,
                false
            )

        if found then

            local coords =
                vector3(
                    x,
                    y,
                    groundZ
                )

            if #(
                coords -
                zone.coords
            ) <= zone.radius then

                return coords

            end

        end

    end

    return vector3(
        zone.coords.x +
            zone.spawnDistance,

        zone.coords.y,

        zone.coords.z
    )

end


--------------------------------------------------
-- NPC SPAWNEN
--------------------------------------------------

local function SpawnPed(zone)

    if #zone.models == 0 then
        return nil
    end

    if #zone.weapons == 0 then
        return nil
    end

    local modelName =
        zone.models[
            math.random(
                1,
                #zone.models
            )
        ]

    local weaponName =
        zone.weapons[
            math.random(
                1,
                #zone.weapons
            )
        ]

    local model =
        LoadModel(modelName)

    if not model then
        return nil
    end

    local coords =
        GetSpawnPosition(zone)

    local heading =
        math.random(
            0,
            359
        ) + 0.0

    local ped =
        CreatePed(
            4,
            model,

            coords.x,
            coords.y,
            coords.z,

            heading,

            true,
            true
        )

    if not DoesEntityExist(ped) then

        SetModelAsNoLongerNeeded(
            model
        )

        return nil

    end


    --------------------------------------------------
    -- MISSION ENTITY
    --------------------------------------------------

    SetEntityAsMissionEntity(
        ped,
        true,
        true
    )


    --------------------------------------------------
    -- RELATIONSHIP GROUP
    --------------------------------------------------

    if WAVE_PED_GROUP then

        SetPedRelationshipGroupHash(
            ped,
            WAVE_PED_GROUP
        )

    end


    --------------------------------------------------
    -- NPC STATS
    --------------------------------------------------

    SetPedArmour(
        ped,
        zone.npcArmor
    )

    SetEntityHealth(
        ped,
        zone.npcHealth
    )

    SetPedAccuracy(
        ped,
        zone.npcAccuracy
    )

    SetPedCanSwitchWeapon(
        ped,
        true
    )

    SetPedDropsWeaponsWhenDead(
        ped,
        false
    )

    SetPedCombatAbility(
        ped,
        2
    )

    SetPedCombatMovement(
        ped,
        2
    )

    SetPedCombatRange(
        ped,
        2
    )

    SetPedFleeAttributes(
        ped,
        0,
        false
    )

    SetPedAsEnemy(
        ped,
        true
    )


    --------------------------------------------------
    -- WAFFE
    --------------------------------------------------

    GiveWeaponToPed(
        ped,
        joaat(weaponName),
        500,
        false,
        true
    )

    SetCurrentPedWeapon(
        ped,
        joaat(weaponName),
        true
    )


    --------------------------------------------------
    -- NPC BLIP
    --------------------------------------------------

    local blip =
        AddBlipForEntity(
            ped
        )

    SetBlipSprite(
        blip,
        1
    )

    SetBlipColour(
        blip,
        1
    )

    SetBlipScale(
        blip,
        0.65
    )

    SetBlipAsShortRange(
        blip,
        false
    )

    BeginTextCommandSetBlipName(
        'STRING'
    )

    AddTextComponentString(
        'Feindlicher NPC'
    )

    EndTextCommandSetBlipName(
        blip
    )


    --------------------------------------------------
    -- NPC SPEICHERN
    --------------------------------------------------

    table.insert(
        activePeds,
        {
            ped = ped,
            blip = blip
        }
    )


    --------------------------------------------------
    -- SPIELER ANGREIFEN
    --------------------------------------------------

    local player =
        PlayerPedId()

    TaskCombatPed(
        ped,
        player,
        0,
        16
    )

    SetPedKeepTask(
        ped,
        true
    )


    SetModelAsNoLongerNeeded(
        model
    )

    return ped

end


--------------------------------------------------
-- NPCs TOT?
--------------------------------------------------

local function AreAllPedsDead()

    if #activePeds == 0 then
        return true
    end

    for _, data in ipairs(
        activePeds
    ) do

        local ped =
            data.ped

        if DoesEntityExist(ped)
        and not IsEntityDead(ped) then

            return false

        end

    end

    return true

end


--------------------------------------------------
-- CLEANUP
--------------------------------------------------

local function CleanupPeds()

    for _, data in ipairs(
        activePeds
    ) do

        local ped =
            data.ped

        local blip =
            data.blip


        --------------------------------------------------
        -- BLIP LÖSCHEN
        --------------------------------------------------

        if blip
        and DoesBlipExist(blip) then

            RemoveBlip(
                blip
            )

        end


        --------------------------------------------------
        -- PED LÖSCHEN
        --------------------------------------------------

        if DoesEntityExist(ped) then

            SetEntityAsMissionEntity(
                ped,
                true,
                true
            )

            DeleteEntity(
                ped
            )

        end

    end

    activePeds = {}

end


--------------------------------------------------
-- NUI ANZEIGE
--------------------------------------------------

local function ShowProgress(
    zone,
    wave
)

    SendNUIMessage({

        action = 'show',

        label = zone.label,

        wave = wave,

        totalWaves = zone.waves

    })

end


local function HideProgress()

    SendNUIMessage({
        action = 'hide'
    })

end


--------------------------------------------------
-- WELLE STARTEN
--------------------------------------------------

local function StartWave(
    zone,
    wave
)

    activeWave = wave

    CleanupPeds()

    ShowProgress(
        zone,
        wave
    )

    Notify(
        ('~r~%s~s~ | ~y~Welle %d/%d~s~'):format(
            zone.label,
            wave,
            zone.waves
        )
    )

    local amount =
        zone.npcsPerWave[wave]

    if not amount then

        amount =
            zone.npcsPerWave[
                #zone.npcsPerWave
            ]

    end

    for i = 1, amount do

        SpawnPed(
            zone
        )

        Wait(250)

    end

end


--------------------------------------------------
-- ZONE ANGRIFF
--------------------------------------------------

local function StartZoneAttack(
    zoneName,
    zone
)

    if waveRunning then
        return
    end


    --------------------------------------------------
    -- COOLDOWN
    --------------------------------------------------

    if zoneCooldowns[zoneName] then

        local remaining =
            zoneCooldowns[zoneName] -
            GetGameTimer()

        if remaining > 0 then
            return
        end

        zoneCooldowns[zoneName] =
            nil

    end


    waveRunning = true

    activeZone =
        zoneName

    activeWave = 0


    Notify(
        ('~r~%s~s~ wurde aktiviert!'):format(
            zone.label
        )
    )


    CreateThread(function()

        for wave = 1,
            zone.waves do

            StartWave(
                zone,
                wave
            )


            --------------------------------------------------
            -- AUF NPCs WARTEN
            --------------------------------------------------

            while not AreAllPedsDead() do

                Wait(500)

            end


            --------------------------------------------------
            -- WELLE BEENDET
            --------------------------------------------------

            CleanupPeds()


            if wave < zone.waves then

                Notify(
                    ('~g~Welle %d abgeschlossen!~s~'):format(
                        wave
                    )
                )

                Wait(
                    Config.TimeBetweenWaves *
                    1000
                )

            end

        end


        --------------------------------------------------
        -- ALLE WELLEN GESCHAFFT
        --------------------------------------------------

        CleanupPeds()

        HideProgress()

        Notify(
            ('~g~%s abgeschlossen!~s~ Alle %d Wellen geschafft.'):format(
                zone.label,
                zone.waves
            )
        )


        TriggerServerEvent(
            'wcc_waveattack:zoneFinished',
            zoneName
        )


        waveRunning = false

        activeZone = nil

        activeWave = 0

    end)

end


--------------------------------------------------
-- COOLDOWN VOM SERVER
--------------------------------------------------

RegisterNetEvent(
    'wcc_waveattack:setCooldown',
    function(
        zoneName,
        seconds
    )

        zoneCooldowns[zoneName] =
            GetGameTimer() +
            (
                seconds * 1000
            )

    end
)


--------------------------------------------------
-- ZONEN ÜBERWACHEN
--------------------------------------------------

CreateThread(function()

    while true do

        local sleep = 1000


        if not waveRunning then

            local player =
                PlayerPedId()

            local playerCoords =
                GetEntityCoords(
                    player
                )


            for zoneName, zone in pairs(
                Config.Zones
            ) do

                local distance =
                    #(
                        playerCoords -
                        zone.coords
                    )


                if distance <=
                    zone.radius then

                    sleep = 250


                    StartZoneAttack(
                        zoneName,
                        zone
                    )

                    break

                end

            end

        end


        Wait(sleep)

    end

end)


--------------------------------------------------
-- ZONEN BLIPS
--------------------------------------------------

CreateThread(function()

    for _, zone in pairs(
        Config.Zones
    ) do

        if zone.blip then

            local blip =
                AddBlipForCoord(
                    zone.coords.x,
                    zone.coords.y,
                    zone.coords.z
                )

            SetBlipSprite(
                blip,
                zone.blipSprite or 1
            )

            SetBlipColour(
                blip,
                zone.blipColor or 1
            )

            SetBlipScale(
                blip,
                0.8
            )

            SetBlipAsShortRange(
                blip,
                true
            )


            BeginTextCommandSetBlipName(
                'STRING'
            )

            AddTextComponentString(
                zone.label
            )

            EndTextCommandSetBlipName(
                blip
            )

        end

    end

end)


--------------------------------------------------
-- DEBUG ZONEN
--------------------------------------------------

CreateThread(function()

    while Config.Debug do

        Wait(0)


        for _, zone in pairs(
            Config.Zones
        ) do

            DrawMarker(
                1,

                zone.coords.x,
                zone.coords.y,
                zone.coords.z - 1.0,

                0.0,
                0.0,
                0.0,

                0.0,
                0.0,
                0.0,

                zone.radius * 2,
                zone.radius * 2,
                2.0,

                255,
                0,
                0,
                50,

                false,
                false,
                2,
                false,
                nil,
                nil,
                false
            )

        end

    end

end)


--------------------------------------------------
-- RESOURCE STOP
--------------------------------------------------

AddEventHandler(
    'onResourceStop',
    function(resource)

        if resource ~=
            GetCurrentResourceName() then

            return

        end


        if Config.DeletePedsOnStop then

            CleanupPeds()

        end


        HideProgress()

    end
)