const hud =
    document.getElementById('waveHud');

const zoneLabel =
    document.querySelector('.zoneLabel');

const wave =
    document.getElementById('wave');

const total =
    document.getElementById('total');

const progress =
    document.getElementById('progress');


window.addEventListener(
    'message',
    function(event) {

        const data =
            event.data || {};


        if (data.action === 'show') {

            const current =
                Number(
                    data.wave || 1
                );

            const max =
                Number(
                    data.totalWaves || 8
                );


            zoneLabel.textContent =
                data.label ||
                'WAVE ATTACK';


            wave.textContent =
                current;


            total.textContent =
                max;


            const percentage =
                Math.min(
                    100,
                    Math.max(
                        0,
                        (
                            current /
                            max
                        ) * 100
                    )
                );


            progress.style.width =
                `${percentage}%`;


            hud.classList.remove(
                'hidden'
            );

        }


        if (data.action === 'hide') {

            hud.classList.add(
                'hidden'
            );

        }

    }
);