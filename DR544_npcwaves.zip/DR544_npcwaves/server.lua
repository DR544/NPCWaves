local zoneCooldowns = {}


--------------------------------------------------
-- ZONE ABGESCHLOSSEN
--------------------------------------------------

RegisterNetEvent(
    'wcc_waveattack:zoneFinished',
    function(zoneName)

        local source = source

        local zone =
            Config.Zones[zoneName]

        if not zone then
            return
        end


        local cooldown =
            tonumber(
                zone.cooldown
            ) or 30


        zoneCooldowns[zoneName] =
            os.time() +
            cooldown


        TriggerClientEvent(
            'wcc_waveattack:setCooldown',
            source,
            zoneName,
            cooldown
        )

    end
)


--------------------------------------------------
-- RESOURCE STOP
--------------------------------------------------

AddEventHandler(
    'onResourceStop',
    function(resource)

        if resource ~=
            GetCurrentResourceName() then

            return

        end

        zoneCooldowns = {}

    end
)